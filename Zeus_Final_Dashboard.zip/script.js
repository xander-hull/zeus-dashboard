
async function analyzeCode() {
  const code = document.getElementById("codeInput").value;
  const output = document.getElementById("output");

  if (!OPENAI_API_KEY) {
    output.textContent = "Missing OpenAI API key!";
    return;
  }

  output.textContent = "Analyzing...";

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [{ role: "user", content: `Check this code for errors:

${code}` }],
      temperature: 0.3
    })
  });

  const data = await response.json();
  output.textContent = data.choices?.[0]?.message?.content || "No response from AI.";
}

function switchTab(tab) {
  document.querySelector("h2").textContent = tab.replace(/(^|\s)\S/g, t => t.toUpperCase());
}
